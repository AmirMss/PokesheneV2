package com.example.pokeshene

class PokemonInfoResponse(val height: Int, val weight: Int, val sprites: Sprites?, val abilities : ArrayList<Abilities>)

class Abilities (val ability: Ability, val is_hidden: Boolean, val slot: Int)

class Ability(val name: String, val url: String)

class Sprites(val back_default: String, val back_shiny: String, val front_default: String, val front_shiny: String)
