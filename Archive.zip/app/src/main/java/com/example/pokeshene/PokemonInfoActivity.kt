package com.example.pokeshene

import android.os.Bundle
import android.widget.Toast
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity
import com.google.gson.GsonBuilder
import com.squareup.picasso.Picasso

import kotlinx.android.synthetic.main.activity_pokemon_info.*
import okhttp3.*
import java.io.IOException

class PokemonInfoActivity : AppCompatActivity() {

    //lateinit var pokemon: Data

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pokemon_info)
        setSupportActionBar(toolbar)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        toolbar.setNavigationOnClickListener {
            finish()
        }

        val pokemon = intent.extras?.getSerializable("pokemon") as Data

        val mainImage = intent.extras?.getString("pokemonMainImage")



        pokemon?.let {
            title = it.name

            mainImage?.let {
                Picasso.get().load(it).into(imageViewPokemon)
            }

            val client = OkHttpClient()
            val request = Request.Builder().url(it.url).build()

            client.newCall(request).enqueue(object: Callback {
                override fun onResponse(call: Call?, response: Response?) {

                    if (response?.code() == 200) {
                        val body = response.body()?.string()

                        val gson = GsonBuilder().create()

                        val res = gson.fromJson(body, PokemonInfoResponse::class.java)

                        runOnUiThread {
                            Picasso.get().load(res.sprites?.front_default).into(imageViewSprite1)
                            Picasso.get().load(res.sprites?.back_default).into(imageViewSprite2)
                            Picasso.get().load(res.sprites?.front_shiny).into(imageViewSprite3)
                            Picasso.get().load(res.sprites?.back_shiny).into(imageViewSprite4)

                            textViewSkill1.text = res.abilities[0].ability.name
                        }
                    }
                }
                override fun onFailure(call: Call?, e: IOException?) {
                    runOnUiThread {
                        Toast.makeText(this@PokemonInfoActivity, e.toString(), Toast.LENGTH_LONG).show()
                    }
                }
            })
        }
    }

}
