package com.example.pokeshene

import androidx.annotation.Keep
import java.io.Serializable


@Keep
class PokemonListResponse(val count: Int, val next: String, val results: ArrayList<Data>)
@Keep
class Data(val name: String, val url: String?): Serializable