package com.example.pokeshene

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.google.gson.GsonBuilder
import kotlinx.android.synthetic.main.activity_main.*
import okhttp3.*
import java.io.IOException

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val client = OkHttpClient()
        val request = Request.Builder().url("https://pokeapi.co/api/v2/pokemon?limit=151").build()

        client.newCall(request).enqueue(object: Callback {
            override fun onResponse(call: Call?, response: Response?) {

                if (response?.code() == 200) {
                    val body = response.body()?.string()

                    val gson = GsonBuilder().create()

                    val res = gson.fromJson(body, PokemonListResponse::class.java)

                    runOnUiThread {
                        listViewPokemonList.adapter = PokemonListRecyclerAdapter(res, this@MainActivity)
                    }
                }
            }
            override fun onFailure(call: Call?, e: IOException?) {
                runOnUiThread {
                    Toast.makeText(this@MainActivity, e.toString(), Toast.LENGTH_LONG).show()
                }
            }
        })
    }
}
