package com.example.pokeshene

import android.app.Activity
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Callback
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.pokemon_list_row_layout.view.*

class PokemonListRecyclerAdapter(val data: PokemonListResponse, val activity: Activity) : RecyclerView.Adapter<PokemonListRecyclerAdapter.CustomViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CustomViewHolder {
        val layoutInflater = LayoutInflater.from(parent?.context)
        val cellForRow = layoutInflater.inflate(R.layout.pokemon_list_row_layout, parent, false)

        return CustomViewHolder(cellForRow)

    }

    override fun getItemCount(): Int {
        return data.results.count()
    }

    override fun onBindViewHolder(holder: CustomViewHolder, position: Int) {
        val pokemon = data.results[position]

        holder.itemView.textViewPokemonName.text = pokemon.name

        //cliquer sur l'image permet d'ouvrir une nouvelle Activity
        //il faut changer pour capturer le click sur toute la cellule
        holder.itemView.imageViewPokemon.setOnClickListener {

            //put @keep and serializable in class in order to pass the object to another activity
            // (PokemonInfoResponse class)
            val intent = Intent(activity, PokemonInfoActivity::class.java)
            intent.putExtra("pokemon", pokemon)
            intent.putExtra("pokemonMainImage", "https://pokeres.bastionbot.org/images/pokemon/" + (position+1) + ".png")

            activity.startActivity(intent)
        }

        pokemon?.url?.let {

            Picasso.get().load("https://pokeres.bastionbot.org/images/pokemon/" + (position+1) + ".png").into(holder.itemView.imageViewPokemon, object :
                Callback {
                override fun onSuccess() {
                    //nothing to do
                }

                override fun onError(e: Exception?) {
                    //load 'empty' image
//                    Picasso.get().load(R.drawable.account_circle).transform(CircleTransform()).into(holder.itemView.imageViewCast)
                }

            })
        }?: run{

//            holder.itemView.imageViewCast.background = ContextCompat.getDrawable(context, R.drawable.account_circle)
        }
    }

    class CustomViewHolder(v: View): RecyclerView.ViewHolder(v) {

    }
}
